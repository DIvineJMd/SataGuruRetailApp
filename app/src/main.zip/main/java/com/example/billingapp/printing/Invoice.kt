import android.content.Context
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintJob
import android.print.PrintManager
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
//import androidx.compose.material3.icons.Icons
//import androidx.compose.material3.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.billingapp.R
import com.example.billingapp.printing.dataH
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceShow(navController: NavController) {
    val context = LocalContext.current



    // Create a WebView object specifically for printing
    val webView = WebView(LocalContext.current)
    var isUploadInitiated by remember { mutableStateOf(false) }
    var isPrintingInitiated by remember { mutableStateOf(false) }

    // Set up WebViewClient to start a print job after the HTML resource is loaded
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
            if (!isPrintingInitiated) {
                Log.i(TAG, "Page finished loading $url")

                // Create a print job
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH:mm:ss", Locale.getDefault())
                val timestamp = dateFormat.format(Date())
                val jobName = "invoice_${timestamp}"
                val printAdapter = webView.createPrintDocumentAdapter(jobName)

                printManager?.print(
                    jobName,
                    printAdapter,
                    PrintAttributes.Builder().build()
                )?.also { printJob ->
                    // Save the job object for later status checking
                    printJobs += printJob
                }
                // Remove the WebView from the view hierarchy
                (webView.parent as? ViewGroup)?.removeView(webView)

                // Set the flag to true to prevent further printing
                isPrintingInitiated = true
            }
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = false
    }

    // Load the HTML content into the WebView
    webView.loadDataWithBaseURL(null, dataH, "text/HTML", "UTF-8", null)

    // Compose UI
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(text = "Invoice")
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xffff6b00)
                ),
                navigationIcon = {
                    IconButton(onClick = { /* Handle back button click */ }) {
                         Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(id = androidx.browser.R.string.fallback_menu_item_copy_link)
                        )
                    }
                }
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(it)
            ) {
                AndroidView(
                    factory = { webView },
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ){view ->
                    // WebView is already loaded, just need to make it visible
                    view.visibility = android.view.View.VISIBLE

                    val htmlContent = dataH // Replace with your HTML content
                    val htmlBytes = htmlContent.toByteArray(Charsets.UTF_8)

                    // Generate a unique filename based on timestamp
                    val dateFormat = SimpleDateFormat("yyyy:MM:dd_HH:mm:ss", Locale.getDefault())
                    val timestamp = dateFormat.format(Date())

                    val filename = "$timestamp.html"

                    // Assuming you have a reference to your Firebase Storage instance and a reference to the desired path
                    val storageReference = FirebaseStorage.getInstance().getReference("Invoices/$filename")

                    // Upload the byte array
                    if (!isUploadInitiated) {
                        storageReference.putBytes(htmlBytes)
                            .addOnSuccessListener {
                                // Handle success, e.g., navigate to "Home"
                                navController.navigate("Home")
                            }
                            .addOnFailureListener {
                                // Handle failure
                            }

                        // Set the flag to true to prevent further uploading
                        isUploadInitiated = true
                    }


                }




                    Spacer(modifier = Modifier.height(16.dp)) // Example spacer for additional space
            }
        }
    )
}




private const val TAG = "InvoiceShow"
private var printJobs: List<PrintJob> = emptyList()


