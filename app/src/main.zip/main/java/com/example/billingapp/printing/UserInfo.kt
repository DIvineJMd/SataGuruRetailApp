package com.example.billingapp.printing

import android.annotation.SuppressLint
import androidx.compose.material3.Text
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType

import com.example.billingapp.workspace.selling.billList
import com.example.billingapp.workspace.selling.generateHtmlContent
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import com.example.billingapp.workspace.selling.HD
import com.example.billingapp.workspace.selling.discount

data class UserData(
    var custname :String ,
    var mobilenuumber:Int,
    var custAdress: String,
    var custAdress2: String

)
var dataH:String=""
class UserInfo  : AppCompatActivity(){

    @SuppressLint("SetJavaScriptEnabled")
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun userinfo(navController:NavController) {
        val data by remember {
            mutableStateOf(UserData("",0,"",""))
        }
        var customerName by remember { mutableStateOf("") }
        var customerMobile by remember { mutableStateOf("") }
        var customerAddress by remember { mutableStateOf("") }
        var customerAddress2 by remember { mutableStateOf("") }

        Scaffold(
            topBar = {
                TopAppBar(
                    modifier = Modifier,
                    title = {
                        Text(text = "Customer details")
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xffff6b00)
                    ),
                    navigationIcon = {
                        IconButton(onClick = { /* do something */ }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Localized description"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { /* do something */ }) {
                            Icon(
                                imageVector =  Icons.Default.Home,
                                contentDescription = "Localized description",
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues = paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp) // Added padding to the entire Column
            ) {

                // Customer Name
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape = RoundedCornerShape(10.dp))
                        .background(color = Color(0xfffff0dd))
                        .padding(vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFE6B00),
                            cursorColor = Color(0xFFFE6B00),
                            focusedLabelColor = Color(0xFFFE6B00)
                        ),
                        label = { Text("Customer Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                    )
                }

                // Customer Mobile Number
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape = RoundedCornerShape(10.dp))
                        .background(color = Color(0xfffff0dd))
                        .padding(vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = customerMobile,
                        onValueChange = { if(customerMobile.length<=10 || it == "\b"){ customerMobile = it }},
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFE6B00),
                            cursorColor = Color(0xFFFE6B00),
                            focusedLabelColor = Color(0xFFFE6B00)
                        ),
                        label = { Text("Customer Mobile Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        keyboardOptions = KeyboardOptions.Default.copy(
                            keyboardType = KeyboardType.Number, // Set the keyboard type to numeric
                            imeAction = ImeAction.Done
                        )

                    )
                    if(customerMobile.length<10 && customerMobile.length!=0){
                        Text(text = "Mobile number incorrect",
                            color = Color.Red,
                            modifier = Modifier.padding(horizontal = 20.dp))
                    }}

                // Customer Address
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape = RoundedCornerShape(10.dp))
                        .background(color = Color(0xfffff0dd))
                        .padding(vertical = 8.dp)
                ){
                    OutlinedTextField(
                        value = customerAddress,
                        onValueChange = { customerAddress = it },
                        label = { Text("Address Line 1") },
                        placeholder = {Text("House no, Street address")},
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFE6B00),
                            cursorColor = Color(0xFFFE6B00),
                            focusedLabelColor = Color(0xFFFE6B00)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape = RoundedCornerShape(10.dp))
                        .background(color = Color(0xfffff0dd))
                        .padding(vertical = 8.dp)
                )  {
                    OutlinedTextField(
                        value = customerAddress2,
                        onValueChange = { customerAddress2 = it },
                        label = { Text("Address Line 2") },
                        placeholder = { Text("Area, City, Zip Code") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFE6B00),
                            cursorColor =Color(0xFFFE6B00),
                            focusedLabelColor = Color(0xFFFE6B00)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp)) // Add some spacing

                // Button
                Button(
                    onClick = {
                        if(customerMobile.isNotBlank() && customerName.isNotBlank() && customerAddress.isNotBlank() && customerAddress2.isNotBlank()) {
                            dataH = customerMobile.toLong().let {
                                generateHtmlContent(customerName,
                                    it, customerAddress, customerAddress2, itemsList = billList,HD.data.html,HD.data.total,HD.data.taxTotal, discount)
                            }.toString()
                          navController.navigate("billbana")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    colors = ButtonDefaults.textButtonColors(
                        Color(0xFFFF6B00)
                    ),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(text ="Proceed for Invoice", color = Color.White,
                        style = TextStyle(
                            fontWeight = FontWeight.Normal,
                            fontSize = 20.sp,

                            ))
                }
            }
        }
    }


//    @Preview
//    @Composable
//    fun MyScreenPreview() {
//        userinfo()
//    }
}