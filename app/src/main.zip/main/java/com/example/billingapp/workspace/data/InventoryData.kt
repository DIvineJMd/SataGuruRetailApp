package com.example.billingapp.workspace.data
data class InventoryPhone(val name: String, val price:Float,val units: Int, val specs: Map<String, String>? = null)
data class phonedata(val name:String)
data class AccessoriesItem(val name: String , val price:Float, val units:Int,)
data class  assdata(var name:String)
